

<?php $__env->startSection('content'); ?>
<section class="content container-fluid mt-4">
    <div class="row">
        <div class="col-md-12">
            <?php if ($__env->exists('partials.errors')) echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="card card-default">
                <div class="card-header">
                    <h5 class="card-title"><?php echo e(__('Crear nuevo')); ?></h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('storeAutorArticulo')); ?>" role="form" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="autores">Selecciona uno o más autores:</label>
                            <select name="autores[]" id="autores" class="form-control" multiple required>
                                <?php $__currentLoopData = $autor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e(encrypt($item->idAutor)); ?>"><?php echo e($item->nombre); ?> <?php echo e($item->apellido); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['autores'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Mostrar autores seleccionados -->
                        <div class="form-group">
                            <label>Autores Seleccionados:</label>
                            <ul id="autoresSeleccionados"></ul>
                        </div>

                        <div class="form-group">
                            <label for="titulo">Título</label>
                            <input type="text" name="titulo" id="titulo" value="<?php echo e(old('titulo')); ?>" required placeholder="Título" class="form-control">
                            <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                       	<div class="form-group">
                            <label for="resumen">Resumen</label>
                            <textarea name="resumen" id="resumen" required placeholder="Resumen" class="form-control"><?php echo e(old('resumen')); ?></textarea>
                            <?php $__errorArgs = ['resumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="contenido">Contenido</label>
                            <textarea name="contenido" id="contenido" required placeholder="Contenido" class="form-control"><?php echo e(old('contenido')); ?></textarea>
                            <?php $__errorArgs = ['contenido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="fecha">Fecha</label>
                            <input type="date" name="fecha" id="fecha" value="<?php echo e(old('fecha')); ?>" required placeholder="Fecha" class="form-control">
                            <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="box-footer mt-4">
                            <button type="button" class="btn btn-primary" onclick="confirmGuardar()"><?php echo e(__('Guardar')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
function confirmGuardar() {
    var confirmacion = confirm("¿Desea guardar los datos?");
    if (confirmacion) {
        // Si el usuario confirma, enviar el formulario
        document.forms[0].submit();
    }
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Equipo\Documents\Universidad\Octavo Semestre\Programación Comercial\Proyecto Final\proyectofinal\resources\views/AutorArticulo/create.blade.php ENDPATH**/ ?>